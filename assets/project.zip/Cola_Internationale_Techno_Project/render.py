import numpy as np, soundfile as sf
from scipy import signal
from numba import njit
from pathlib import Path
import json,subprocess
P=Path(__file__).parent
SR=44100; BPM=138; beat=60/BPM; bar=4*beat; stop=136*bar; duration=246.0
rng=np.random.default_rng(138)
N=int(duration*SR); music=np.zeros((N,2),np.float32); vocal=np.zeros_like(music)
def add(buf,x,start,gain=1,pan=0):
 s=round(start*SR); n=min(len(x),len(buf)-s)
 if n<=0:return
 buf[s:s+n,0]+=x[:n]*gain*np.sqrt((1-pan)/2)
 buf[s:s+n,1]+=x[:n]*gain*np.sqrt((1+pan)/2)
def time(d):return np.arange(int(d*SR))/SR
def hp(x,hz):return signal.sosfilt(signal.butter(2,hz,fs=SR,btype='high',output='sos'),x)
def note(m):return 440*2**((m-69)/12)
@njit
def acidfilter(x,cut,res):
 out=np.zeros(len(x)); low=0.; band=0.
 for i in range(len(x)):
  f=2*np.sin(np.pi*cut[i]/44100)
  high=np.tanh(x[i]-low-res*band)
  band+=f*high; low+=f*band
  out[i]=low
 return out
# punchy pitch-swept kick with a clipped analogue body
t=time(.48); phase=2*np.pi*(48*t+110*.023*(1-np.exp(-t/.023)))
kick=np.tanh(2.5*np.sin(phase))*np.exp(-t/ .16)+.2*rng.normal(size=len(t))*np.exp(-t/.004)
kick*=np.minimum(t/.001,1)
t=time(.095); hat=hp(rng.normal(size=len(t)),7200)*np.exp(-t/.018)
t=time(.24); oh=hp(rng.normal(size=len(t)),6500)*np.exp(-t/.075)
t=time(.25); clap=hp(rng.normal(size=len(t)),1300)*sum(np.exp(-np.maximum(t-a,0)/.035)*(t>=a) for a in [0,.011,.024])*.3
t=time(.36); metal=sum(np.sin(2*np.pi*f*t)*np.exp(-t/(.035+.025*j)) for j,f in enumerate([371,827,1471,2317]))*.22
# 136 bars: intro 0-16, entry 16-32, drop 32-72, low break 72-88, build 88-104, final 104-136
for b in range(136):
 start=b*bar; drop=32<=b<72 or b>=104; entry=16<=b<32; build=88<=b<104
 active=drop or entry or build
 if active:
  for k in range(4):
   if b in [31,71,103] and k>=3:continue
   add(music,kick,start+k*beat,1.25 if drop else .85)
 elif b<16 and b%4==0: add(music,kick,start,.28)
 elif 72<=b<88 and b%2==0: add(music,kick,start,.38)
 if active:
  for k in range(8):
   add(music,hat,start+k*beat/2,.13 if k%2==0 else .20,(-1)**k*.34)
   if k%2==1 and (drop or b>23):add(music,oh,start+k*beat/2,.14,.3)
  if drop or build:
   for k in [1,3]:add(music,clap,start+k*beat,.32,-.15)
  if drop:
   for k in [2.75,5.5,7.25]:add(music,metal,start+k*beat/2,.23 if b<104 else .34,(-1)**int(k)*.6)
 if b>=8:
  # independently articulated sub bass, sidechain shaped on every beat
  for k in [.5,1.25,1.75,2.5,3.25,3.75] if active else [0,2]:
   t=time(beat*.65); f=note(33 if b%8<6 else 40)
   x=(np.sin(2*np.pi*f*t)+.18*np.sin(4*np.pi*f*t))*np.exp(-t/ .18)*np.minimum(t/.008,1)
   add(music,x,start+k*beat,.52 if active else .24)
 if b>=12:
  seq=[45,45,57,45,52,45,61,57,45,49,45,57,52,45,61,47]
  density=16 if active else 8
  for k in range(density):
   if not drop and k%4==3:continue
   st=start+k*bar/density; length=beat*(.40 if k%3 else .7); t=time(length)
   m=seq[(k+(b//4)*2)%16]+(12 if b>=120 and k%4==2 else 0)
   f=note(m); glide=1+.12*np.exp(-t/.018) if k%3==0 else np.ones_like(t)
   ph=np.cumsum(f*glide)/SR; saw=2*(ph%1)-1
   openness=(.5+.5*np.sin(b*.19))
   base=340+2700*openness if drop else 220+500*openness
   if build:base=300+2200*(b-88)/16
   cut=np.minimum(7200,base+(1800 if drop else 750)*np.exp(-t/.055))
   x=acidfilter(saw,cut,.19); x=np.tanh(x*3)*np.exp(-t/.12)*np.minimum(t/.002,1)
   add(music,x,st,.31 if drop else .15,-.16)
   if drop:add(music,x,st+beat*.75,.055,.65)
 if b>=24:
  for k in range(8):
   if not active and k%2:continue
   t=time(beat*.6); f=note([69,76,81,85,81,76,73,64][(k+b//4)%8])
   x=(np.sin(2*np.pi*f*t)+.25*np.sin(2*np.pi*f*2.002*t))*np.exp(-t/.055)*np.minimum(t/.003,1)
   add(music,x,start+k*beat/2,.065 if drop else .035,np.sin(k*2)*.75)
   add(music,x,start+k*beat/2+beat*.75,.025,-np.sin(k*2)*.75)
 if b in [28,60,96,128]:
  t=time(4*bar); noise=hp(rng.normal(size=len(t)),2200); x=noise*(t/t[-1])**2*.09
  add(music,x,start,1,.1)
 if b in [31,103,135]:
  for k in range(16):add(music,metal,start+k*bar/16,.06+.12*k/16,(-1)**k*.45)
# Distorted resonant low rumble, offbeat recovery after each quarter-note kick.
t=time(beat); carrier=np.sin(2*np.pi*55*t+.8*np.sin(2*np.pi*83*t))
rumble=signal.sosfilt(signal.butter(3,230,fs=SR,output='sos'),np.tanh(carrier*4))
rumble*=np.minimum(t/.11,1)**2*np.minimum((beat-t)/.04,1)*.24
for b in list(range(32,72))+list(range(104,136)):
 for k in range(4):add(music,rumble,b*bar+k*beat,1)
# Final-drop sixteenth hats and grinding machine ticks.
for b in range(104,136):
 for k in range(16):
  if k%2:add(music,hat,b*bar+k*beat/4,.07,(-1)**k*.55)
 if b%2==0:
  for k in [1.75,2.75,3.5]:add(music,metal,b*bar+k*beat,.18,-.45)
# Familiar melodic response between the sung phrases, detuned synth with beat-synced echo.
hook=[64, 69, 68, 71, 69, 64, 61, 66, 62, 66, 71, 69, 68, 66, 64, 62, 61]
lengths=np.array([0.5, 1.5, 0.5, 0.5, 0.5, 0.5, 0.5, 2, 1.5, 0.5, 1.5, 0.5, 0.5, 0.5, 0.5, 0.5, 3]); lengths=lengths/lengths.sum()*16
for hb in [0,34,68,96,104,120]:
 at=hb*bar
 for k,m in enumerate(hook):
  t=time(lengths[k]*beat*.94); f=note(m)
  ph=f*t; osc=signal.sawtooth(2*np.pi*ph)*.45+signal.sawtooth(2*np.pi*ph*1.003)*.3+np.sin(2*np.pi*ph)*.3
  osc=signal.sosfilt(signal.butter(2,2400,fs=SR,output="sos"),osc)
  env=np.minimum(t/.009,1)*np.minimum((t[-1]-t)/.035,1)*np.exp(-t/.4)
  tone=osc*env
  add(music,tone,at,.19 if hb else .11,-.25)
  add(music,tone,at+beat*.75,.06,.5)
  at+=lengths[k]*beat
# Fizzy industrial atmosphere with filtered noise, no words or extra voice fragments
t=np.arange(int(stop*SR))/SR
fizz=hp(rng.normal(size=len(t)),9500)*(.003+.003*np.sin(2*np.pi*.11*t))
add(music,fizz,0,.7,.3)
# hard stop with 3 ms anti-click ramp, all music and delay tails end here
end=int(stop*SR); music[end:]=0; music[end-132:end]*=np.linspace(1,0,132)[:,None]
# Exact language order repeated four times, then Chinese. No vocal delays that could break order.
lines=json.loads((P/'lyrics.json').read_text()); events=[]
bars=[4,10,16,22,28,40,46,52,58,64,76,82,88,94,100,106,112,118,124,130]
for j,start in enumerate([b*bar+.10 for b in bars]+[stop+.6]):
 i=j%5; x,sr=sf.read(P/'sung'/f'{i}.wav'); assert sr==SR
 x=x*.68
 # Stereo microshift and short synthetic ambience, no detached lyric repeats.
 add(vocal,x,start,1,0)
 add(vocal,x,start+.012,.16,-.65)
 add(vocal,x,start+.021,.16,.65)
 s=int((start-.04)*SR); e=min(N,int((start+len(x)/SR+.15)*SR))
 duck=np.ones(e-s)*.79; r=min(2205,len(duck)//2); duck[:r]=np.linspace(1,.79,r); duck[-r:]=np.linspace(.79,1,r)
 music[s:e]*=duck[:,None]
 events.append(dict(language=lines[i][0],text=lines[i][1],start=round(start,4),end=round(start+len(x)/SR,4),source=f'sung/{i}.wav'))
assert events[-1]['end']<duration
mix=music+vocal
# smooth bus saturation, normalized with ample oversampling headroom
mix=np.tanh(mix*1.3)
peak=float(np.max(np.abs(mix))); mix*=10**(-1.5/20)/peak
sf.write(P/'When_I_Drink_Cola_Internationale_Techno.wav',mix,SR,subtype='PCM_24')
sf.write(P/'vocals_only.wav',vocal,SR,subtype='PCM_24')
(P/'vocal_timeline.json').write_text(json.dumps(events,ensure_ascii=False,indent=2))
subprocess.run(['ffmpeg','-v','error','-y','-i',str(P/'When_I_Drink_Cola_Internationale_Techno.wav'),'-codec:a','libmp3lame','-b:a','320k','-metadata','title=当我喝可乐的时候 / When I Drink Cola','-metadata','artist=Experimental Cola Project',str(P/'When_I_Drink_Cola_Internationale_Techno.mp3')],check=True)
print(json.dumps({'duration':duration,'bpm':BPM,'peak_dbfs':float(20*np.log10(np.max(abs(mix)))),'vocal_events':len(events),'last_voice':events[-1]},ensure_ascii=False),flush=True)
