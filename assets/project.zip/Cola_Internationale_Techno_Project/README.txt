当我喝可乐的时候 / When I Drink Cola — Internationale / Hard Acid Techno
246 seconds; 138 BPM; 4/4; A major melodic theme; 44.1 kHz stereo 24-bit WAV and 320 kbps MP3.

Melody: opening of The Internationale, Pierre De Geyter (1888), transposed/notated in A major. Reference: https://trillian.mit.edu/~jc/music/abc/anthem/Internationale.abc (John Chambers collection). No existing recording sampled. The opening theme is fitted to the supplied cola sentences, with rhythmic adaptations for a sixteen-beat vocal phrase. Only the five supplied cola sentences are sung, four language cycles plus Chinese at the end.

Changes from previous version: new Internationale melody in both vocals and lead; harder 48-Hz pitch-swept kick, distorted offbeat rumble, sixteenth-note acid sequence with stronger resonance and drive, rolling offbeat bass, louder metallic percussion, extra final-drop hats, and reduced instrumental ducking under vocals. Synthesized electronic singing is generated from native-language TTS spectral envelopes with WORLD pitch and time resynthesis. This is robotic singing; native-speaker pronunciation has not been independently audited, and Mandarin/Vietnamese lexical tones are altered by melody.

Structure: bars 0-16 minimal opening; 16-32 rhythmic entry; 32-72 first drop; 72-88 low-frequency break; 88-104 buildup; 104-136 final drop; music cuts at 236.521739 seconds; final Chinese sung phrase begins 237.121739 seconds.

Reproduce with Python 3.12, FFmpeg (libmp3lame), C/C++ compiler:
  CC=gcc CXX=g++ python -m pip install -r requirements.txt
  python tts.py
  python sing.py
  python render.py
  python verify.py
Cached speech and synthesized singing are included. tts.py only requires network if cached speech is missing. render.py and sing.py are final standalone sources; do not rerun revise.py.

Verification includes exact file durations, sample/decoded peaks, 21 non-silent vocal regions, language/text order, and measured vocal pitch deviation from the score. loudness.txt contains FFmpeg ebur128/true-peak measurement. No claim of human listening or native-speaker certification.
