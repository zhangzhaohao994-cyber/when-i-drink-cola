from pathlib import Path
import numpy as np,soundfile as sf,pyworld as pw
from scipy import signal
import json
P=Path(__file__).parent; sr=44100; beat=60/138
# Internationale opening theme; source: John Chambers ABC, key A major.
melody=np.array([64, 69, 68, 71, 69, 64, 61, 66, 62, 66, 71, 69, 68, 66, 64, 62, 61])
lengths=np.array([0.5, 1.5, 0.5, 0.5, 0.5, 0.5, 0.5, 2, 1.5, 0.5, 1.5, 0.5, 0.5, 0.5, 0.5, 0.5, 3]); lengths=lengths/lengths.sum()*16
edges=np.r_[0,np.cumsum(lengths)]*beat
scores=[]
for lang in range(5):
 x,_=sf.read(P/'voices'/f'{lang}.wav'); nz=np.flatnonzero(abs(x)>.012);x=x[max(0,nz[0]-500):nz[-1]+1000].astype(np.float64)
 f0,t=pw.harvest(x,sr,f0_floor=65,f0_ceil=700,frame_period=5)
 f0=pw.stonemask(x,f0,t,sr); sp=pw.cheaptrick(x,f0,t,sr); ap=pw.d4c(x,f0,t,sr)
 # Locate nearby acoustic minima for rhythmic boundaries without removing any syllables.
 energy=np.sqrt(np.mean(sp,axis=1)); source=[0]
 for k in range(1,len(melody)):
  center=k/len(melody)*(len(t)-1); rad=(len(t)-1)/len(melody)*.27
  a=max(source[-1]+1,int(center-rad)); b=min(len(t)-2,int(center+rad))
  source.append(a+int(np.argmin(energy[a:b+1])))
 source.append(len(t)-1); source=np.array(source)*.005
 ot=np.arange(0,edges[-1],.005); mapped=np.interp(ot,edges,source)
 def interp(mat):
  idx=np.minimum(mapped/.005,len(mat)-1.00001);lo=idx.astype(int);w=(idx-lo)[:,None]
  return np.ascontiguousarray(mat[lo]*(1-w)+mat[np.minimum(lo+1,len(mat)-1)]*w)
 s=interp(sp); a=interp(ap); voiced=np.interp(mapped,t,f0)>50
 ix=np.minimum(np.searchsorted(edges,ot,side='right')-1,len(melody)-1)
 nf=440*2**((melody[ix]-69)/12)
 # Flat note centres, tiny vibrato on held vowels; all original speech intonation is replaced.
 nf=nf*(1+.0025*np.sin(2*np.pi*5.2*ot)); nf[~voiced]=0
 # More periodic voiced excitation creates a hard tuned electronic singing voice.
 a[voiced,:]*=.48
 y=pw.synthesize(np.ascontiguousarray(nf),s,a,sr,frame_period=5)
 y=signal.sosfilt(signal.butter(2,110,fs=sr,btype='highpass',output='sos'),y)
 y=np.tanh(y*1.1); y/=max(abs(y)); sf.write(P/'sung'/f'{lang}.wav',y,sr,subtype='PCM_24')
 scores.append({'language_index':lang,'midi_notes':melody.tolist(),'note_edges_seconds':edges.tolist(),'voiced_frames':int(sum(voiced)),'method':'WORLD spectral-envelope-preserving resynthesis; explicit A-major Internationale melody and beat-aligned time map'})
 print('Sung voice',lang,'ready',len(y)/sr,flush=True)
(P/'melody_score.json').write_text(json.dumps(scores,indent=2))
