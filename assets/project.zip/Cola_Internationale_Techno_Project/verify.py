import soundfile as sf,numpy as np,json,subprocess
from pathlib import Path
p=Path(__file__).parent
x,s=sf.read(p/'When_I_Drink_Cola_Internationale_Techno.wav'); v,_=sf.read(p/'vocals_only.wav'); events=json.loads((p/'vocal_timeline.json').read_text()); lines=json.loads((p/'lyrics.json').read_text())
assert len(events)==21
for j,e in enumerate(events):
 assert e['language']==lines[j%5][0] and e['text']==lines[j%5][1]
 a=round(e['start']*s); b=round(e['end']*s)
 assert np.sqrt(np.mean(v[a:b]**2))>.01
 if j: assert e['start']>events[j-1]['end']
assert len(x)/s==246 and np.max(abs(x))<1
subprocess.run(['ffmpeg','-v','error','-y','-i',str(p/'When_I_Drink_Cola_Internationale_Techno.mp3'),str(p/'decoded_mp3.wav')],check=True)
m,ms=sf.read(p/'decoded_mp3.wav'); assert abs(len(m)/ms-246)<.1
report={'wav_duration_seconds':len(x)/s,'sample_rate':s,'channels':x.shape[1],'wav_sample_peak_dbfs':float(20*np.log10(np.max(abs(x)))),'mp3_decoded_peak_dbfs':float(20*np.log10(np.max(abs(m)))),'vocal_events':len(events),'languages_in_order':[z[0] for z in lines],'complete_cycles':4,'final_utterance':events[-1],'verification':'All 21 scheduled vocal segments contain non-silent rendered speech; exact supplied text and sequence validated against synthesis sources. No independent native-speaker or ASR pronunciation audit.'}
(p/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)); print(json.dumps(report,ensure_ascii=False,indent=2))
(p/'decoded_mp3.wav').unlink()

import pyworld as pw
score=json.loads((p/'melody_score.json').read_text()); checks=[]
for i in range(5):
 y,sr=sf.read(p/'sung'/f'{i}.wav'); y=np.ascontiguousarray(y)
 f,t=pw.harvest(y,sr,f0_floor=100,f0_ceil=700,frame_period=5)
 edges=np.array(score[i]['note_edges_seconds']); notes=np.array(score[i]['midi_notes'])
 ix=np.minimum(np.maximum(np.searchsorted(edges,t,side='right')-1,0),len(notes)-1)
 voiced=f>0; midi=69+12*np.log2(np.maximum(f,1)/440)
 cents=100*abs(midi[voiced]-notes[ix[voiced]])
 checks.append({'language_index':i,'median_pitch_error_cents':float(np.median(cents)),'voiced_frames':int(sum(voiced)),'target_unique_notes':int(len(set(notes)))})
report['melodic_pitch_checks']=checks
(p/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps(checks,indent=2))
