from pathlib import Path
from gtts import gTTS
import json, subprocess
P=Path(__file__).parent
lines=[('zh-CN','当我喝可乐的时候，什么事也不会发生。'),('en','When I drink cola, nothing happens.'),('fr','Quand je bois du cola, il ne se passe rien.'),('de','Wenn ich Cola trinke, passiert nichts.'),('vi','Khi tôi uống cola, không có chuyện gì xảy ra.')]
for i,(lang,text) in enumerate(lines):
 p=P/'voices'/f'{i}.mp3'
 if not p.exists(): gTTS(text=text,lang=lang,slow=False).save(str(p))
 subprocess.run(['ffmpeg','-y','-v','error','-i',str(p),'-ar','44100','-ac','1',str(p.with_suffix('.wav'))],check=True)
 print(lang,text,flush=True)
(P/'lyrics.json').write_text(json.dumps(lines,ensure_ascii=False,indent=2))
