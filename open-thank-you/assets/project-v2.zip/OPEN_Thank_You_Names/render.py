from pathlib import Path
import numpy as np,soundfile as sf,json,subprocess
from scipy import signal
from numba import njit
P=Path(__file__).parent;O=P/'output';O.mkdir(exist_ok=True)
SR=44100;BPM=138;BEAT=60/BPM;BAR=BEAT*4;STOP=114*BAR;DURATION=204.;N=round(DURATION*SR)
rng=np.random.default_rng(222026)
music=np.zeros((N,2),np.float32);drums=np.zeros_like(music);vocals=np.zeros_like(music)
def add(buf,x,t,g=1,pan=0):
 s=round(t*SR);n=min(len(x),len(buf)-s)
 if s<0 or n<=0:return
 buf[s:s+n,0]+=x[:n]*g*np.sqrt((1-pan)/2);buf[s:s+n,1]+=x[:n]*g*np.sqrt((1+pan)/2)
def tm(d):return np.arange(round(d*SR))/SR
def hz(n):return 440*2**((n-69)/12)
def filt(x,cut,typ='lowpass',order=2):return signal.sosfilt(signal.butter(order,cut,fs=SR,btype=typ,output='sos'),x)
@njit
def resonant(x,cut):
 out=np.zeros(len(x));lo=0.;band=0.
 for i in range(len(x)):
  f=2*np.sin(np.pi*cut[i]/44100);hi=np.tanh(x[i]-lo-.23*band);band+=f*hi;lo+=f*band;out[i]=lo
 return out
# Tight kick, open/closed hats and resonant metal, independently synthesized.
t=tm(.49);ph=2*np.pi*(47*t+115*.024*(1-np.exp(-t/.024)))
kick=np.tanh(2.1*np.sin(ph))*np.exp(-t/.145)+.13*rng.normal(size=len(t))*np.exp(-t/.004);kick*=np.minimum(t/.001,1)
t=tm(.09);hat=filt(rng.normal(size=len(t)),7600,'highpass')*np.exp(-t/.019)
t=tm(.25);openhat=filt(rng.normal(size=len(t)),6700,'highpass')*np.exp(-t/.085)
t=tm(.23);clap=filt(rng.normal(size=len(t)),1500,'highpass')*sum(np.exp(-np.maximum(t-a,0)/.038)*(t>=a) for a in [0,.012,.025])*.26
t=tm(.33);metal=sum(np.sin(2*np.pi*f*t)*np.exp(-t/(.04+j*.014)) for j,f in enumerate([389,811,1499,2423]))*.17
for b in range(114):
 at=b*BAR;drop=8<=b<52 or b>=80;entry=4<=b<8;build=64<=b<80;soft=52<=b<64
 active=drop or entry or build or soft
 for k in range(4):
  if b<4 and (b%4 or k):continue
  if soft and k%2:continue
  if b in [7,51,79,113] and k==3:continue
  add(drums,kick,at+k*BEAT,1.02 if drop else .74 if active else .3)
 if active:
  for k in range(8):
   add(drums,hat,at+k*BEAT/2,.12 if k%2==0 else .19,(-1)**k*.25)
   if k%2 and not soft:add(drums,openhat,at+k*BEAT/2,.105,.35)
  for k in [1,3]:
   if not soft:add(drums,clap,at+k*BEAT,.26,-.15)
  if drop:
   for k in [1.75,2.75,3.5]:add(drums,metal,at+k*BEAT,.19 if b<96 else .24,(-1)**int(k)*.5)
  if b>=96:
   for k in range(16):
    if k%2:add(drums,hat,at+k*BEAT/4,.065,(-1)**k*.6)
 if b>=4:
  root=29 if b<96 else [29,36,29,34,29,36][b%6]
  for k in [.5,1.25,1.75,2.5,3.25,3.75] if active else [.5,2.5]:
   t=tm(BEAT*.45);f=hz(root);x=(np.sin(2*np.pi*f*t)+.18*np.sin(4*np.pi*f*t))*np.exp(-t/.13)*np.minimum(t/.006,1)
   add(music,x,at+k*BEAT,.44 if drop else .26)
 if b>=8:
  seq=[41,53,48,41,45,48,53,43,41,48,57,53,46,45,43,48]
  for k in range(16 if active and not soft else 8):
   count=16 if active and not soft else 8;st=at+k*BAR/count;t=tm(BEAT*(.4 if k%3 else .65));m=seq[(k+b//4)%16]
   f=hz(m);phase=np.cumsum(f*(1+.08*np.exp(-t/.018) if k%3==0 else np.ones_like(t)))/SR
   saw=2*(phase%1)-1;base=300+(2100 if drop else 700)*(.5+.5*np.sin(b*.17))
   if build:base=350+2100*(b-64)/16
   cut=np.minimum(6800,base+(1900 if drop else 850)*np.exp(-t/.05));x=np.tanh(resonant(saw,cut)*2.5)*np.exp(-t/.105)*np.minimum(t/.003,1)
   add(music,x,st,.19 if drop else .10,-.18)
   if drop:add(music,x,st+BEAT*.75,.033,.6)
 if b in [4,48,76,108]:
  t=tm(4*BAR);x=filt(rng.normal(size=len(t)),3200,'highpass')*(t/t[-1])**2*.07;add(music,x,at,1,.25)
 if b in [7,51,79,113]:
  for k in range(16):add(drums,metal,at+k*BAR/16,.05+.12*k/16,(-1)**k*.5)
# Warm sustained harmonies, pulsed away from kick attacks.
for b in range(0,114,4):
 root=53;minor=False;t=tm(4*BAR)
 notes=[root,root+(3 if minor else 4),root+7];x=np.zeros(len(t))
 for m in notes:x+=np.sin(2*np.pi*hz(m)*t)+.12*np.sin(2*np.pi*hz(m)*1.003*t)
 x=filt(x,1550)*np.minimum(t/.12,1)*np.minimum((t[-1]-t)/.2,1)*(.3+.7*np.minimum((t%BEAT)/.16,1))
 add(music,x,b*BAR,.023,-.3)
# The complete Happy Birthday melody recurs as the recognizable lead in a 4/4 techno grid.
score=json.loads((P/'score.json').read_text());mel=score['midi'];lengths=score['beats']
for b in [0,8,14,20,26,32,38,44,52,64,80,96,102,108]:
 at=b*BAR
 for i,(m,d) in enumerate(zip(mel,lengths)):
  t=tm(d*BEAT*.96);f=hz(m);x=.62*np.sin(2*np.pi*f*t)+.18*signal.sawtooth(2*np.pi*f*t)+.16*np.sin(2*np.pi*f*1.003*t)+.12*np.sin(4*np.pi*f*t)
  x=filt(x,2600);x*=np.minimum(t/.007,1)*np.minimum((t[-1]-t)/.04,1)*np.exp(-t/.72)
  add(music,x,at,.24 if b>=96 else .18,-.15);add(music,x,at+BEAT*.75,.035,.55);at+=d*BEAT
# Subtle industrial rumble supplies offbeat weight during the strongest sections.
t=tm(BEAT);rum=filt(np.tanh(3*np.sin(2*np.pi*54*t+.7*np.sin(2*np.pi*87*t))),240)
rum*=np.minimum(t/.11,1)**2*np.minimum((BEAT-t)/.04,1)*.13
for b in list(range(8,52))+list(range(80,114)):
 for k in range(4):add(music,rum,b*BAR+k*BEAT)
# Hard music stop, no instrumental tail beneath the closing line.
end=round(STOP*SR);music[end:]=0;drums[end:]=0
for bus in [music,drums]:bus[end-132:end]*=np.linspace(1,0,132)[:,None]
es=json.loads((P/'events.json').read_text());credits={c['id']:c for c in json.loads((P/'credits.json').read_text())};timeline=[];name_ratios=[]
for e in es:
 x,sr=sf.read(P/'sung'/f'{e["key"]}.wav');assert sr==SR;start=e['bar']*BAR+.055;finish=start+len(x)/SR
 assert finish<(e['bar']+e['bars'])*BAR+.055 and finish<DURATION
 add(vocals,x,start,1.12 if e['kind']=='name' else 1.02)
 if e['kind']!='name':
  add(vocals,x,start+.012,.085,-.6);add(vocals,x,start+.020,.085,.6)
 s=round(max(0,start-.04)*SR);f=min(N,round((finish+.10)*SR));r=min(1764,(f-s)//2)
 for bus,level in [(music,.28 if e['kind']=='name' else .52),(drums,.52 if e['kind']=='name' else .78)]:
  env=np.full(f-s,level);env[:r]=np.linspace(1,level,r);env[-r:]=np.linspace(level,1,r);bus[s:f]*=env[:,None]
 a=round(start*SR);z=round(finish*SR)
 if e['kind']=='name':
  vr=np.mean(vocals[a:z]**2)+1e-12;br=np.mean((music[a:z]+drums[a:z])**2)+1e-12;ratio=float(10*np.log10(vr/br))
  if ratio<7.8:
   extra=10**((ratio-7.8)/20);env=np.full(f-s,extra);env[:r]=np.linspace(1,extra,r);env[-r:]=np.linspace(extra,1,r)
   music[s:f]*=env[:,None];drums[s:f]*=env[:,None]
  name_ratios.append(dict(key=e['key'],vocal_to_backing_db=float(10*np.log10(vr/(np.mean((music[a:z]+drums[a:z])**2)+1e-12)))))
 if e['kind']!='name':
  word,wsr=sf.read(P/'sung/word_open.wav');zword=min(N,a+len(word));vr=np.mean(vocals[a:zword]**2)+1e-12;br=np.mean((music[a:zword]+drums[a:zword])**2)+1e-12
  ratio=float(10*np.log10(vr/br))
  if ratio<13:
   extra=10**((ratio-13)/20);left=max(0,a-300);right=min(N,zword+900);env=np.full(right-left,extra);env[:300]=np.linspace(1,extra,300);env[-900:]=np.linspace(extra,1,900)
   music[left:right]*=env[:,None];drums[left:right]*=env[:,None]
 person=credits.get(e['person']);timeline.append(dict(key=e['key'],start=round(start,4),end=round(finish,4),text=e['text'],translation=e['translation'],kind=e['kind'],person=e['person'],role_zh=person['role_zh'] if person else '',role_en=person['role_en'] if person else ''))
mix=np.tanh((music+drums+vocals)*1.15);mix*=10**(-1.6/20)/max(np.max(abs(mix)),1e-9)
sf.write(O/'OPEN_Thank_You.wav',mix,SR,subtype='PCM_24')
subprocess.run(['ffmpeg','-y','-v','error','-i',str(O/'OPEN_Thank_You.wav'),'-c:a','libmp3lame','-b:a','320k','-metadata','title=OPEN Thank You','-metadata','artist=OPEN International Performance Art Festival',str(O/'OPEN_Thank_You.mp3')],check=True)
(P/'timeline.json').write_text(json.dumps(timeline,ensure_ascii=False,indent=2));(P/'name_balance.json').write_text(json.dumps(name_ratios,ensure_ascii=False,indent=2))
def stamp(t):
 h=int(t//3600);m=int(t%3600//60);s=t%60;return f'{h:02}:{m:02}:{s:06.3f}'
vtt='WEBVTT\n\n';lrc='[ti:OPEN Thank You]\n[ar:OPEN International Performance Art Festival]\n'
for i,e in enumerate(timeline):
 vtt+=f'{i+1}\n{stamp(e["start"])} --> {stamp(e["end"])}\n{e["text"]}\n{e["translation"]}\n\n'
 lrc+=f'[{int(e["start"]//60):02}:{e["start"]%60:05.2f}]{e["text"]} / {e["translation"]}\n'
(O/'subtitles.vtt').write_text(vtt);(O/'OPEN_Thank_You.lrc').write_text(lrc)
# Compact static waveform for the website, generated from the actual final master.
bins=np.array_split(np.mean(mix,axis=1),200);wave=[round(float(np.sqrt(np.mean(x*x))),5) for x in bins]
(O/'track.json').write_text(json.dumps({'title':'OPEN Thank You','duration':DURATION,'bpm':BPM,'waveform':wave,'events':timeline,'credits':list(credits.values()),'sections':[{'start':0,'label':'欢迎 / Welcome'},{'start':8*BAR,'label':'艺术家 / Artists'},{'start':52*BAR,'label':'策展与影像 / Curator & images'},{'start':64*BAR,'label':'工作团队 / Festival team'},{'start':96*BAR,'label':'器乐尾声 / Instrumental outro'}]},ensure_ascii=False))
print(json.dumps({'duration':DURATION,'sample_peak_dbfs':float(20*np.log10(np.max(abs(mix)))),'vocal_events':len(timeline),'people':len(credits),'min_name_vocal_to_backing_db':min(z['vocal_to_backing_db'] for z in name_ratios)},ensure_ascii=False),flush=True)
