OPEN Thank You — Names Edition / 中英文唱名版
138 BPM, 4/4, 3:24, stereo 44.1 kHz, 24-bit WAV and 320 kbps MP3.

Lyrics contain exactly two short festival introductions, 44 individual name segments (22 people, Chinese then English/Latin-script name), and the closing phrase Open, thank you. All longer praise/poetry passages from the earlier edition have been removed. credits.json is the complete poster-derived roster with the user's corrections 最高 / Highest and 括号 / Parentheses.

The Happy Birthday theme is retained in a new techno arrangement. Name melodies use short tune fragments matched to syllable count. WORLD resynthesis sustains vowels while keeping consonant timing. Names remain centred and dry; backing is automatically reduced for a minimum 7 dB vocal margin. No existing music recording is sampled.

Important pronunciation fix: Open is always synthesized by English TTS as the single word "Open.". The same intact sung word clip is embedded before the Chinese introduction, English introduction and closing phrase. No Chinese TTS engine synthesizes or spells Open. Verification compares all three embedded word prefixes against the identical source and checks presence in the master.

Rebuild (Python 3.12; FFmpeg with libmp3lame; C/C++ compiler may be needed):
  CC=gcc CXX=g++ python -m pip install -r requirements.txt
  python prepare.py
  python tts.py
  python sing.py
  python render.py
  python verify.py
Cached raw WAV sources are included, so tts.py can run without network requests. Generated WAV and MP3 appear in output/. The website/ folder contains portable website source. To use it locally, copy output/OPEN_Thank_You.mp3 to website/assets/open-thank-you-v2.mp3, then serve website/ with an ordinary static HTTP server.

The styled photographic background is based on the user's supplied performance photograph, using image generation for the requested techno treatment. Source audio verification does not constitute a human native-speaker pronunciation audit.
