from pathlib import Path
import json
P=Path(__file__).parent;c=json.loads((P/'credits.json').read_text());events=[]
def event(key,bar,bars,lang,text,translation,kind='intro',person=None,parts=None,tts_text=None):
 events.append(dict(key=key,bar=bar,bars=bars,language=lang,text=text,translation=translation,kind=kind,person=person,parts=parts,tts_text=tts_text or text))
event('intro_zh',1,3,'zh-CN','Open，国际行为艺术节。','Open International Performance Art Festival.',parts=[{'language':'en','text':'Open.','source':'word_open'},{'language':'zh-CN','text':'国际行为艺术节。','source':'festival_zh'}])
event('intro_en',4,4,'en','Open International Performance Art Festival.','Open，国际行为艺术节。',parts=[{'language':'en','text':'Open.','source':'word_open'},{'language':'en','text':'International Performance Art Festival.','source':'festival_en'}])
voices={'p02':'fr','p04':'fr','p05':'fr','p08':'de'}
for i,p in enumerate(c):
 event(p['id']+'_zh',8+i*4,2,'zh-CN',p['zh'],p['en'],'name',p['id'],tts_text=p['zh'].replace('·T.','，T'))
 event(p['id']+'_en',10+i*4,2,voices.get(p['id'],'en'),p['en'],p['zh'],'name',p['id'],tts_text='Kim vee' if p['id']=='p06' else p['en'])
event('closing',114.20,2,'en','Open, thank you.','Open，谢谢。','closing',parts=[{'language':'en','text':'Open.','source':'word_open'},{'language':'en','text':'Thank you.','source':'thank_you'}])
(P/'events.json').write_text(json.dumps(events,ensure_ascii=False,indent=2))
print(len(c),'people,',len(events),'vocal segments; only 3 short non-name phrases')
