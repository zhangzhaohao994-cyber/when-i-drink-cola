from pathlib import Path
import json,subprocess
from concurrent.futures import ThreadPoolExecutor,as_completed
from gtts import gTTS
P=Path(__file__).parent;es=json.loads((P/'events.json').read_text());jobs={}
for e in es:
 if e.get('parts'):
  for part in e['parts']:jobs[part['source']]=(part['language'],part['text'])
 else:jobs[e['key']]=(e['language'],e['tts_text'])
def task(item):
 key,(lang,text)=item;wav=P/'raw'/f'{key}.wav'
 if wav.exists():return key
 mp3=P/'raw'/f'{key}.mp3'
 if not mp3.exists():gTTS(text=text,lang=lang).save(str(mp3))
 subprocess.run(['ffmpeg','-y','-v','error','-i',str(mp3),'-ar','44100','-ac','1',str(wav)],check=True)
 return key
with ThreadPoolExecutor(max_workers=4) as ex:
 for f in as_completed([ex.submit(task,j) for j in jobs.items()]):print(f.result(),flush=True)
(P/'open_pronunciation.json').write_text(json.dumps({'method':'All three audible Open tokens are assembled from the same complete English TTS word source. No Chinese engine synthesizes the word Open. No letter-by-letter rendering.','language':'en','source_text':'Open.','source':'raw/word_open.wav','occurrences':['intro_zh','intro_en','closing']},ensure_ascii=False,indent=2))
