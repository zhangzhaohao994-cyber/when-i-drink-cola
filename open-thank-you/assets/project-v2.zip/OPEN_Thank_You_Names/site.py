from pathlib import Path
import json,html,shutil
P=Path(__file__).parent;D=Path('/workspace/sites/open-thank-you/dist');A=D/'assets';A.mkdir(exist_ok=True)
credits=json.loads((P/'credits.json').read_text());track=json.loads((P/'output/track.json').read_text());events=track['events'];eh=html.escape
for src,dst in [('OPEN_Thank_You.mp3','open-thank-you-v2.mp3'),('track.json','track-v2.json'),('subtitles.vtt','subtitles-v2.vtt'),('OPEN_Thank_You.lrc','open-thank-you-v2.lrc')]:shutil.copy(P/'output'/src,A/dst)
parts=[]
for role,title,sub in [('artist','参展艺术家','PARTICIPATING ARTISTS'),('curator','策展人','CURATOR'),('image','摄影摄像','PHOTOGRAPHY & VIDEOGRAPHY'),('team','工作团队','FESTIVAL TEAM')]:
 cards=[]
 for c in credits:
  if c['role']!=role:continue
  t=next(e['start'] for e in events if e['person']==c['id'])
  cards.append(f'<button class="person" type="button" data-person="{c["id"]}" data-seek="{t}" aria-label="收听 {eh(c["zh"])} / {eh(c["en"])}"><span class="person-zh">{eh(c["zh"])}</span><span class="person-en" lang="en">{eh(c["en"])}</span><span class="person-play" aria-hidden="true">↗</span></button>')
 parts.append(f'<section class="credit-group"><div class="group-label"><h3>{title}</h3><span>{sub}</span></div><div class="people-grid">{"".join(cards)}</div></section>')
lyrics=[]
for e in events:
 lyrics.append(f'<li><button type="button" data-seek="{e["start"]}"><time>{int(e["start"]//60):02}:{int(e["start"]%60):02}</time><span>{eh(e["text"])}<small>{eh(e["translation"])}</small></span></button></li>')
# The waveform is a real image, derived from the exported master.
w=track['waveform'];mx=max(w);lines=[]
for i,v in enumerate(w):
 h=max(3,v/mx*78);x=i*5+2.5;lines.append(f'<path d="M{x:.1f},{45-h/2:.2f}v{h:.2f}"/>')
svg='<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 90" role="img" aria-labelledby="t"><title id="t">OPEN Thank You 完整音频声波图</title><g stroke="#b9b2a2" stroke-width="2.8" stroke-linecap="round">'+''.join(lines)+'</g></svg>'
(A/'waveform.svg').write_text(svg)
page='''<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#11110f"><meta name="description" content="OPEN Thank You：第22届OPEN国际行为艺术节闭幕聚餐音乐。生日快乐歌旋律 × Techno，22位艺术家、策展人及工作人员的中英文唱名，同步字幕与完整音频下载。"><title>OPEN Thank You · 第22届国际行为艺术节</title><link rel="icon" href="assets/favicon.svg" type="image/svg+xml"><link rel="stylesheet" href="style.css?v=names2"></head><body><main>
<header><a href="#" class="brand">OPEN<span>THE 22ND / 国际行为艺术节</span></a><span class="header-note">CLOSING DINNER · 2026.10.25</span></header>
<section class="cover-section" aria-labelledby="title"><div class="cover-heading"><div><div class="eyebrow"><i></i> PERFORMANCE ART · GRATITUDE · TECHNO</div><h1 id="title">OPEN <em>Thank You.</em></h1><p class="cover-subtitle">22 位伙伴，中英文唱名。</p></div><button id="hero-play" class="play-button" type="button" aria-controls="audio" aria-pressed="false">▶ 播放闭幕音乐</button></div>
<figure class="illustrated-cover"><img src="assets/performance-techno-v2.webp" width="1672" height="941" alt="用户提供的现场照片经Techno风格化：两位表演者站在庭院池塘中，周围有环形瓶子装置、植物与黑白银气球，画面以冷青色和荧光绿呈现。" fetchpriority="high"><figcaption><span>第22届 OPEN 国际行为艺术节</span><strong>OPEN Thank You</strong><small>22 位伙伴 / 中英文唱名</small></figcaption></figure>
<div class="cover-footnote"><span>生日快乐主题 × Techno · 中英文唱名</span><span>138 BPM / 03:24 / 22 位伙伴</span></div></section>
<section class="player" aria-label="完整音乐播放器"><div class="player-top"><div><span class="track-no">01</span><div class="track-name">OPEN Thank You<small>闭幕聚餐音乐 / Closing dinner soundtrack</small></div></div><span class="quality">STEREO / FULL VERSION</span></div>
<div class="wave-wrap"><img src="assets/waveform.svg" alt="歌曲声波图" width="1000" height="90"><div class="wave-progress" id="wave-progress" aria-hidden="true"><img src="assets/waveform.svg" alt="" width="1000" height="90"></div><input id="seek" type="range" min="0" max="204" step=".1" value="0" aria-label="播放进度，单位秒"></div><div class="time-row"><span id="elapsed">00:00</span><span>03:24</span></div>
<audio id="audio" controls preload="none" src="assets/open-thank-you-v2.mp3"><track kind="subtitles" src="assets/subtitles-v2.vtt" srclang="zh" label="中英字幕">你的浏览器不支持音频播放，请使用下载链接。</audio><p id="status" class="hint" aria-live="polite">点击播放。中英文姓名逐一演唱。</p></section>
<section class="subtitle-panel" aria-label="同步中英字幕"><div id="caption-role" class="section-label">LIVE LYRICS / 同步字幕</div><p id="caption-main">OPEN，Thank you。</p><p id="caption-translation" lang="en">Thank you for being here.</p><span id="section-now">欢迎 / Welcome</span></section>
<section class="credits" aria-labelledby="credits-title"><div class="section-label">NAMES / 名单</div><div class="credits-heading"><h2 id="credits-title">全部名单</h2><p>艺术家、策展人、摄影与工作团队。<br>点击姓名，跳转收听。</p></div>__CREDITS__</section>
<details class="full-lyrics"><summary>完整字幕 / FULL LYRICS <span>＋</span></summary><ol>__LYRICS__</ol></details>
<section class="downloads"><div><div class="section-label">DOWNLOADS</div><h2>下载</h2><p>音乐、字幕、工程。</p></div><div class="download-links"><a href="assets/open-thank-you-v2.mp3" download>下载完整 MP3 <span>320 kbps ↗</span></a><a href="assets/open-thank-you-v2.lrc" download>下载同步歌词 <span>中英字幕 LRC ↗</span></a><a href="assets/waveform.svg" download>下载声波图片 <span>SVG ↗</span></a><a href="assets/project.zip" download>下载制作工程 <span>代码 / 名单 / 声音素材 ↗</span></a></div></section>
<footer><span>OPEN THANK YOU · 第22届OPEN国际行为艺术节</span><span>闭幕聚餐音乐 · 2026</span></footer></main><script src="app.js?v=names2" defer></script></body></html>'''
(D/'index.html').write_text(page.replace('__CREDITS__',''.join(parts)).replace('__LYRICS__',''.join(lyrics)))
(A/'favicon.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" fill="#11110f"/><circle cx="32" cy="32" r="22" fill="#f84b32"/><circle cx="32" cy="32" r="10" fill="#11110f"/></svg>')
