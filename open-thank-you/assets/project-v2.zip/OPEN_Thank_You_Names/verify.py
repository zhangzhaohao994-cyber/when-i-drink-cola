from pathlib import Path
import soundfile as sf,numpy as np,json,subprocess
P=Path(__file__).parent;O=P/'output'
x,sr=sf.read(O/'OPEN_Thank_You.wav');assert sr==44100 and x.shape[1]==2;assert len(x)/sr==204.;assert np.max(abs(x))<1
credits=json.loads((P/'credits.json').read_text());events=json.loads((P/'events.json').read_text());timeline=json.loads((P/'timeline.json').read_text());assert len(credits)==22 and len(timeline)==47
correlations=[]
for c in credits:
 pair=[e for e in timeline if e['person']==c['id']];assert len(pair)==2
 assert pair[0]['text']==c['zh'] and pair[1]['text']==c['en']
 for e in pair:
  y,ys=sf.read(P/'sung'/f'{e["key"]}.wav');assert ys==sr
  start=round(e['start']*sr);mixed=x[start:start+len(y)].mean(axis=1);n=min(len(y),len(mixed));assert np.sqrt(np.mean(mixed**2))>.02
  corr=float(np.corrcoef(mixed[:n],y[:n])[0,1]);assert corr>.80,(e['key'],corr)
  correlations.append({'key':e['key'],'name':e['text'],'source_to_master_correlation':corr})
for a,b in zip(timeline,timeline[1:]):assert a['end']<b['start'],(a,b)
assert timeline[-1]['end']<204
subprocess.run(['ffmpeg','-y','-v','error','-i',str(O/'OPEN_Thank_You.mp3'),'-f','wav',str(O/'decoded-check.wav')],check=True)
m,ms=sf.read(O/'decoded-check.wav');assert abs(len(m)/ms-204)<.1;assert np.max(abs(m))<1
balance=json.loads((P/'name_balance.json').read_text());assert len(balance)==44 and min(e['vocal_to_backing_db'] for e in balance)>7
report={'title':'OPEN Thank You','duration_seconds':len(x)/sr,'bpm':138,'meter':'4/4','theme':'Happy Birthday to You (melody only, adapted to techno)','sample_rate':sr,'channels':2,'wav_peak_dbfs':float(20*np.log10(np.max(abs(x)))),'mp3_decoded_peak_dbfs':float(20*np.log10(np.max(abs(m)))),'people':22,'artist_count':sum(c['role']=='artist' for c in credits),'curator_count':sum(c['role']=='curator' for c in credits),'photography_count':sum(c['role']=='image' for c in credits),'team_count':sum(c['role']=='team' for c in credits),'independent_name_segments':44,'total_vocal_segments':47,'all_bilingual_names_covered':True,'no_overlapping_utterances':True,'min_name_vocal_to_backing_db':min(e['vocal_to_backing_db'] for e in balance),'min_source_to_master_name_correlation':min(e['source_to_master_correlation'] for e in correlations),'name_presence_checks':correlations,'pronunciation_note':'Native-language TTS sources with restrained melodic WORLD resynthesis. Technical checks establish source presence and coverage; no independent human native-speaker pronunciation audit.'}
(O/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));(O/'decoded-check.wav').unlink()
print(json.dumps({k:v for k,v in report.items() if k!='name_presence_checks'},ensure_ascii=False,indent=2))

word,_=sf.read(P/'sung/word_open.wav');checks=[]
for key in ['intro_zh','intro_en','closing']:
 y,_=sf.read(P/'sung'/f'{key}.wav');assert np.max(abs(y[:len(word)]-word))<2e-7
 e=next(e for e in timeline if e['key']==key);start=round(e['start']*sr);mx=x[start:start+len(word)].mean(axis=1);corr=float(np.corrcoef(mx,word)[0,1]);assert corr>.75,(key,corr)
 checks.append({'segment':key,'whole_English_word_source_identical':True,'source_to_master_correlation':corr})
assert len([e for e in timeline if e['kind']!='name'])==3
report['open_word_checks']=checks;report['non_name_phrases']=3;report['revision']='Concise name-led edition; vowel-sustained Happy Birthday motifs; whole English Open word in both language contexts.'
(O/'verification.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print(json.dumps(checks,indent=2))
