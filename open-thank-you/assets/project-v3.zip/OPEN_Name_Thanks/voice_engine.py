from pathlib import Path
import json,numpy as np,soundfile as sf,pyworld as pw
from scipy import signal,ndimage
from concurrent.futures import ProcessPoolExecutor,as_completed
P=Path(__file__).parent;SR=44100;BEAT=60/138
EN_SYLL=[4,2,5,2,5,3,2,3,4,3,4,2,3,2,3,3,3,3,3,3,3,2]
def trim(x):
 n=np.flatnonzero(abs(x)>.009);return np.ascontiguousarray(x[max(0,n[0]-220):min(len(x),n[-1]+800)],dtype=np.float64)
def voice(source,length,notes,inflection=.15,periodicity=.78):
 x=trim(source);f0,t=pw.harvest(x,SR,f0_floor=65,f0_ceil=750,frame_period=5);f0=pw.stonemask(x,f0,t,SR)
 sp=pw.cheaptrick(x,f0,t,SR);ap=pw.d4c(x,f0,t,SR);v=f0>50
 # Sustain vowels to fit the beat; preserve consonant durations as far as possible.
 vd=sum(v)*.005;ud=len(v)*.005-vd;stretch=np.clip((length-ud)/max(vd,.01),.65,4)
 weights=np.where(v,stretch,1.);warp=np.r_[0,np.cumsum(weights[:-1])]*.005;warp*=length/max(warp[-1],.005)
 ot=np.arange(0,length,.005);mapped=np.interp(ot,warp,t)
 fi=np.minimum(mapped/.005,len(sp)-1.00001);lo=fi.astype(int);w=(fi-lo)[:,None]
 def mat(m):return np.ascontiguousarray(m[lo]*(1-w)+m[np.minimum(lo+1,len(m)-1)]*w)
 s=mat(sp);a=mat(ap);old=np.interp(mapped,t,f0);voiced=old>50
 # Note changes follow source syllable positions, while vowels carry the sustain.
 ix=np.minimum((mapped/max(t[-1],.001)*len(notes)).astype(int),len(notes)-1)
 midi=ndimage.gaussian_filter1d(np.asarray(notes)[ix].astype(float),1.4)
 med=np.median(old[voiced]) if np.any(voiced) else 180;delta=np.clip(12*np.log2(np.maximum(old,65)/med),-3,3)*inflection
 nf=440*2**((midi+delta-69)/12);nf[~voiced]=0;a[voiced]*=periodicity
 y=pw.synthesize(np.ascontiguousarray(nf),s,a,SR,frame_period=5)
 y=signal.sosfilt(signal.butter(2,[110,11500],fs=SR,btype='bandpass',output='sos'),y);y=np.tanh(y*1.05)
 y*=.25/max(np.sqrt(np.mean(y*y)),1e-6);y*=min(1,.83/max(abs(y)))
 fade=160;y[:fade]*=np.linspace(0,1,fade);y[-fade:]*=np.linspace(1,0,fade)
 return y

def name_notes(n):
 motifs={1:[65],2:[60,65],3:[62,60,65],4:[60,62,60,65],5:[60,60,62,60,65],6:[60,60,62,60,65,64],7:[60,60,62,60,65,64,62],8:[60,60,62,60,65,64,62,60]}
 return motifs[min(n,8)]
def make(e):
 if e['kind']=='name':
  x,_=sf.read(P/'raw'/f'{e["key"]}.wav');j=int(e['person'][1:])
  n=(sum('\u4e00'<=c<='\u9fff' for c in e['text'])+int('T.' in e['text'])) if e['language']=='zh-CN' else EN_SYLL[j]
  beats=3 if n<=2 else 4 if n==3 else 5 if n<=5 else 6.5
  y=voice(x,beats*BEAT,name_notes(n),.33 if e['language']=='zh-CN' else .15)
 else:
  # The Open word is the SAME complete English-synthesized word in Chinese and English contexts.
  op,_=sf.read(P/'sung/word_open.wav');suffix=e['parts'][1]['source'];x,_=sf.read(P/'raw'/f'{suffix}.wav')
  if e['kind']=='closing':target=1.0;notes=[65,64]
  elif e['key']=='intro_zh':target=3.2;notes=[60,60,62,60,65,64,62,60]
  else:target=4.35;notes=[60,60,62,60,65,64,60,60,62,60,67,65]
  tail=voice(x,target,notes,.2,.8);y=np.r_[op,np.zeros(round(.075*SR)),tail]
 sf.write(P/'sung'/f'{e["key"]}.wav',y,SR,subtype='PCM_24')
 return dict(key=e['key'],kind=e['kind'],duration=len(y)/SR,text=e['text'])
if __name__=='__main__':
 op,_=sf.read(P/'raw/word_open.wav');op=trim(op)
 # One uninterrupted word, natural timing and vowel contour. No slicing into letter-like units.
 word=voice(op,max(.52,len(op)/SR),[60],.42,.85)
 sf.write(P/'sung/word_open.wav',word,SR,subtype='PCM_24')
 es=json.loads((P/'events.json').read_text());report=[]
 with ProcessPoolExecutor(max_workers=3) as ex:
  for f in as_completed([ex.submit(make,e) for e in es]):
   r=f.result();report.append(r);print(r['key'],round(r['duration'],3),flush=True)
 (P/'vocal_build.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
