from pathlib import Path
import json,re,html,shutil,hashlib
P=Path(__file__).parent;D=Path('/workspace/cola-publish/open-thank-you');A=D/'assets';eh=html.escape
track=json.loads((P/'output/track.json').read_text());credits={c['id']:c for c in track['credits']};events=track['events']
for src,dst in [('OPEN_Thank_You.mp3','open-thank-you-v3.mp3'),('track.json','track-v3.json'),('subtitles.vtt','subtitles-v3.vtt'),('OPEN_Thank_You.lrc','open-thank-you-v3.lrc')]:shutil.copy(P/'output'/src,A/dst)
h=(D/'index.html').read_text()
# Keep the page structure and stylesheet intact; update only content, asset versions and cue metadata.
for old,new in [('open-thank-you-v2.mp3','open-thank-you-v3.mp3'),('track-v2.json','track-v3.json'),('subtitles-v2.vtt','subtitles-v3.vtt'),('open-thank-you-v2.lrc','open-thank-you-v3.lrc'),('waveform-v2.svg','waveform-v3.svg'),('project-v2.zip','project-v3.zip'),('app.js?v=names2','app.js?v=thanks3')]:h=h.replace(old,new)
h=h.replace('22 位伙伴，中英文唱名。','22 位伙伴，中英文姓名＋谢谢你。').replace('点击姓名，跳转收听。','点击姓名，试听中英文「姓名＋谢谢你」。').replace('中英文姓名逐一演唱。','中文姓名＋谢谢你 / English name + thank you.').replace('点击播放。每个名字，都值得被听见。','点击播放，或点击姓名试听中英文感谢。')
h=h.replace('<p id="caption-main">OPEN，Thank you。</p>','<p id="caption-main">Open，谢谢你。</p>').replace('<p id="caption-translation" lang="en">Thank you for being here.</p>','<p id="caption-translation" lang="en">Open, thanks.</p>')
def button(m):
 tag=m.group(0);pid=re.search(r'data-person="([^"]+)"',tag).group(1);pair=[e for e in events if e['person']==pid]
 tag=re.sub(r'data-seek="[^"]+"',f'data-seek="{pair[0]["start"]}"',tag)
 tag=re.sub(r'aria-label="[^"]*"',f'aria-label="收听 {eh(pair[0]["text"])} / {eh(pair[1]["text"])}"',tag)
 tag=tag[:-1]+f' data-preview-end="{pair[1]["end"]+.075:.4f}">'
 return tag
h=re.sub(r'<button class="person"[^>]*>',button,h)
items=[]
for e in events:items.append(f'<li><button type="button" data-seek="{e["start"]}"><time>{int(e["start"]//60):02}:{int(e["start"]%60):02}</time><span>{eh(e["text"])}<small>{eh(e["translation"])}</small></span></button></li>')
h=re.sub(r'(<details class="full-lyrics">.*?<ol>).*?(</ol></details>)',lambda m:m.group(1)+''.join(items)+m.group(2),h,flags=re.S)
(D/'index.html').write_text(h)
w=track['waveform'];mx=max(w);lines=[]
for i,v in enumerate(w):
 height=max(3,v/mx*78);lines.append(f'<path d="M{i*5+2.5:.1f},{45-height/2:.2f}v{height:.2f}"/>')
(A/'waveform-v3.svg').write_text('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1000 90" role="img" aria-labelledby="t"><title id="t">OPEN Thank You 姓名感谢版完整音频声波图</title><g stroke="#b9b2a2" stroke-width="2.8" stroke-linecap="round">'+''.join(lines)+'</g></svg>')
# These files define the unchanged visual format and photo.
(P/'site_format.json').write_text(json.dumps({'stylesheet_sha256':hashlib.sha256((D/'style.css').read_bytes()).hexdigest(),'background_sha256':hashlib.sha256((A/'performance-techno-v2.webp').read_bytes()).hexdigest()},indent=2))
print('Website content updated; stylesheet and background unchanged.')
