from pathlib import Path
import json,numpy as np,soundfile as sf
from voice_engine import voice
P=Path(__file__).parent;SR=44100;BEAT=60/138
if __name__=='__main__':
 params={'thanks_zh':(2.5*BEAT,[65,67,65]),'thanks_en':(2*BEAT,[67,65]),'thanks_short':(1.25*BEAT,[65])}
 for key,(d,notes) in params.items():
  x,_=sf.read(P/'raw'/f'{key}.wav');y=voice(x,d,notes,.28 if key.endswith('zh') else .16,.82);sf.write(P/'sung'/f'{key}.wav',y,SR,subtype='PCM_24')
 zh,_=sf.read(P/'sung/thanks_zh.wav');en,_=sf.read(P/'sung/thanks_en.wav');short,_=sf.read(P/'sung/thanks_short.wav');op,_=sf.read(P/'names/word_open.wav')
 sf.write(P/'sung/word_open.wav',op,SR,subtype='PCM_24');intro_zh=np.r_[op,np.zeros(round(.075*SR)),zh];intro_en=np.r_[op,np.zeros(round(.075*SR)),short]
 report=[]
 for e in json.loads((P/'events.json').read_text()):
  if e['kind']=='name':
   n,_=sf.read(P/'names'/f'{e["key"]}.wav');tail=zh if e['key'].endswith('_zh') else en;y=np.r_[n,np.zeros(round(.11*SR)),tail]
  elif e['key']=='intro_zh':y=intro_zh
  elif e['key']=='intro_en':y=intro_en
  else:y=np.r_[intro_zh,np.zeros(round(.14*SR)),intro_en]
  assert len(y)/SR<e['bars']*4*BEAT-.06
  sf.write(P/'sung'/f'{e["key"]}.wav',y,SR,subtype='PCM_24');report.append(dict(key=e['key'],kind=e['kind'],duration=len(y)/SR,text=e['text']))
 (P/'vocal_build.json').write_text(json.dumps(report,ensure_ascii=False,indent=2));print('44 name + thanks phrases and 3 Open cues ready')
