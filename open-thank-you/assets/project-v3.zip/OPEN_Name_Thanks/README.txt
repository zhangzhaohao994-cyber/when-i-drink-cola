OPEN Thank You — Name + Thanks Edition
204 seconds / 138 BPM / 4/4 / F major / Happy Birthday theme × Techno.

Every one of the 22 people has a Chinese name followed by 谢谢你, and an English/Latin-script name followed by thank you. Opening: Open 谢谢你 / Open thanks. Closing repeats these short phrases. All original name voices and the whole English word Open are preserved exactly. Chinese and English gratitude tails use native-language TTS with melodic resynthesis. There are no added long lyrics.

The complete roster is in credits.json; actual audio cues are in timeline.json. Artwork, stylesheet and page structure remain unchanged. Selecting a name plays that person's Chinese and English thank-you phrases, then pauses; the main play button plays the full track.

Rebuild (Python 3.12, FFmpeg/libmp3lame; C/C++ compiler may be required for pyworld):
  CC=gcc CXX=g++ python -m pip install -r requirements.txt
  python prepare.py
  python tts.py
  python sing.py
  python render.py
  python verify.py
Cached names/ and raw/ voice files are included. voice_engine.py is a helper imported by sing.py. No network TTS request is required when all cached sources exist. output/ contains the regenerated WAV, MP3, subtitles and technical verification. Website source is in website/; copy output/OPEN_Thank_You.mp3 to website/assets/open-thank-you-v3.mp3 for local static hosting.

Verification checks both the original name prefixes and gratitude tails against every rendered cue, and their presence in the final master. No claim of an independent human native-speaker pronunciation audit is made.
