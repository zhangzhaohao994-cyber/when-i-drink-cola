from pathlib import Path
import json,math,soundfile as sf
P=Path(__file__).parent;BAR=4*60/138;credits=json.loads((P/'credits.json').read_text());events=[]
def event(key,bar,bars,lang,text,translation,kind='intro',person=None):
 events.append(dict(key=key,bar=bar,bars=bars,language=lang,text=text,translation=translation,kind=kind,person=person))
event('intro_zh',1,3,'zh-CN','Open，谢谢你。','Open, thanks.')
event('intro_en',4,4,'en','Open, thanks.','Open，谢谢你。')
cursor=8
for p in credits:
 for suffix,lang,text,translation,thanks in [('zh','zh-CN',p['zh']+'，谢谢你。',p['en']+', thank you.',2.5*60/138),('en','en',p['en']+', thank you.',p['zh']+'，谢谢你。',2*60/138)]:
  key=p['id']+'_'+suffix;d=sf.info(P/'names'/f'{key}.wav').duration+.11+thanks
  bars=max(2,math.ceil((d+.075)/BAR));event(key,cursor,bars,lang,text,translation,'name',p['id']);cursor+=bars
event('closing',114.20,2,'en','Open，谢谢你。Open, thanks.','Open, thanks. Open，谢谢你。','closing')
assert cursor<=104
(P/'events.json').write_text(json.dumps(events,ensure_ascii=False,indent=2));print(len(credits),'people;',len(events),'vocal cues; names end at bar',cursor)
