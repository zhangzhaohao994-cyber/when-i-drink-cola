from pathlib import Path
from gtts import gTTS
import subprocess
P=Path(__file__).parent
for key,lang,text in [('thanks_zh','zh-CN','谢谢你。'),('thanks_en','en','Thank you.'),('thanks_short','en','Thanks.')]:
 wav=P/'raw'/f'{key}.wav'
 if wav.exists():continue
 mp3=P/'raw'/f'{key}.mp3'
 if not mp3.exists():gTTS(text=text,lang=lang).save(str(mp3))
 subprocess.run(['ffmpeg','-y','-v','error','-i',str(mp3),'-ar','44100','-ac','1',str(wav)],check=True)
 print(key,flush=True)
